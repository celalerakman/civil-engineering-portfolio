# CE-R01 Commercial Control

Commercial reporting for a six-block residential development, 288 apartments and 70,560 m2.

The Excel workbook connects the 32-item BOQ baseline to 384 accepted-quantity records, 408 accrued-cost records, 24 variations, 64 purchasing commitments and twelve interim certificates. The cost report shows revised budget, earned value, actual cost, ETC, EAC, CPI and base-scope SPI.

Change approvals, reporting month, remaining-work rates, retention and advance recovery are editable. Pending changes remain outside approved budget and certification, while their incurred costs stay in actual cost. Purchase commitments are disclosed separately to avoid double-counting ETC.

Independent portfolio project by Celal Erakman. Progress, costs, changes and commitments are constructed portfolio inputs, not client records. Direct-cost reporting excludes preliminaries, overhead, finance, tax, FX and inflation. See Basis for calculation definitions.

Open in Microsoft Excel. Validation.json records independent total comparisons, live input-change checks and exported-file inspection. Microsoft Excel itself was not executed in this environment.
