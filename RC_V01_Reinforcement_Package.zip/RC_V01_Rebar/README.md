# RC-V01 reinforcement scheduling

Celal Erakman | Rev 01 | 24 October 2026

24 villas, two repeated types, 6,048 m2 scheduled floor area.

The nine-sheet workbook contains 10,608 bar-mark groups, 1,968 physical elements, 105,672 scheduled bars and 243.196 tonnes of net reinforcement. It includes live developed/cut lengths, mass, per-mark stock estimates, diameter procurement and villa/pour releases.

Open RC_V01_Reinforcement_BBS.xlsx. Blue numeric controls are editable. The Basis and Shapes sheets define dimensions, scope and update conventions. Stock estimates include trim/offcuts and exclude transfer of offcuts between marks.

RC_V01_Scheduling_Geometry.dxf provides two villa grid/foundation plans with schematic bottom meshes. It is scheduling geometry; the complete bar schedule is in the workbook.

Independent scheduling study. Reinforcement is prescribed input, with project design approval still open. Stairs, tie beams, walls, chairs and spacers are excluded. It is not an issued-for-construction reinforcement design.
