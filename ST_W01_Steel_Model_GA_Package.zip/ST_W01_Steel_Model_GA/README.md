# ST-W01 | Steel warehouse model and general arrangement

Celal Erakman | Independent portfolio project | Rev 01 | 24 October 2026

96 x 60 m footprint; three 20 m spans; twelve 8 m longitudinal bays; 12 m eaves; 15% roof pitch. 774 marked pieces and 289.566 t net theoretical steel.

- IFC4: parametric swept sections, hollow profiles, circular plate holes, unique GUIDs and quantities.
- DXF: 3D profiled member blocks plus eight A1 general-arrangement layouts.
- GLB: named member objects for interactive viewing.
- PDF: eight A1 drawing sheets; print at 100% to retain the stated scales.
- CSV: piece register and section summary. Model coordinates in metres; drawing dimensions in millimetres.
- Validation: schema, geometry-volume reconciliation, DXF audit, register and object counts.

Nominal axes and sharp-corner section geometry. Density 7850 kg/m3. Weights exclude weld metal, bolts, gussets and coatings. Joint cuts, connections and structural resistance are outside this GA issue. This is an independent modelling and quantity study.

Formats: https://docs.ifcopenshell.org/ifcopenshell-python/geometry_creation.html | https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html
