# IN-E01 Earthworks and Formation

300 x 240 m site platform. The CAD package contains separate existing and proposed 3D triangulated surfaces, 0.5 m contours, seven section locations and local coordinates in metres. Both surfaces contain 775 vertices and 1,440 triangles. OBJ meshes accompany the layered DXF.

The 12-sheet A3 PDF contains three plans, a 3D surface review, seven cross sections and a material-balance schedule. CSV files retain all surface points, triangle volumes and section coordinates.

Formation cut and fill are integrated from the stripped existing terrain against the proposed formation. Triangles crossing the cut/fill line are clipped before separate signed-volume integration. Topsoil stripping is separate. Reuse suitability and bank-to-compacted yield are explicit assumed ratios. Independent 1 m numerical integration and DXF audit results are in Validation.json.

Independent portfolio study by Celal Erakman. Source terrain is constructed, not a measured survey. No geotechnical or drainage approval asserted. Batters, retaining walls, shoring, haul routes and disposal rates excluded.
