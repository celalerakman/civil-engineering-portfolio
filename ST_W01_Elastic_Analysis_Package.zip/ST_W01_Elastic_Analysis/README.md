# ST-W01 | Elastic frame analysis - Rev 01

Celal Erakman | 24 October 2026

Interior transverse frame of the 96 x 60 m warehouse: three 20 m spans, 12 m eaves, 8 m tributary width. The report contains the basis, 17 combinations, force diagrams, service deformations, base actions, stability sensitivity and design review register.

Open the 15-page PDF first. The CSV station register contains 16,184 rows (kN, kNm, metres and MPa). The JSON records assumptions and numerical verification.

Independent preliminary analysis portfolio. Site actions are prescribed study inputs. Gross stress, service sway and elastic stability identify required design revisions; this issue is not a completed structural design.
